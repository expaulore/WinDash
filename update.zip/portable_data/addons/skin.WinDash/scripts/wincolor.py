import os
import xbmc
import time
import os.path
from os import path
app = "wincolor.exe"
dir = xbmc.translatePath('special://xbmc/')
os.startfile(dir + app)
time.sleep(2)
if os.path.isfile(dir + "accent.txt"):
   file = open(dir + "accent.txt")
   line = file.read().replace("\n", " ")
   file.close()
   xbmc.executebuiltin("Skin.SetString(gamercolor2, " + line + ")")
