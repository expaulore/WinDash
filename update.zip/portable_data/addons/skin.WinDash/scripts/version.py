﻿import os
import xbmc
import time
dir = xbmc.translatePath('special://xbmc/')
with open(dir + "currentversion.txt") as f:
    txt = f.read()
xbmc.executebuiltin("Skin.SetString(currentver, " + txt + ")")
